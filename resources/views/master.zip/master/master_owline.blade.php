<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
@include('master.header_owline')
<body style="background-color:#e5e5e5">
	@yield('content')
</body>
</html> 