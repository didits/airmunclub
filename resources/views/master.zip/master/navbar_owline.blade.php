<div class="tm-navbar" data-uk-sticky='{"media":767,"showup":true,"animation":"uk-animation-slide-top"}'>

    <nav class="uk-navbar">

        <a class="uk-navbar-brand" href="http://airlanggamunclub.com">
            <img class="tm-logo uk-responsive-height" src="{{URL::to('assets/img/logo/1.jpg')}}" alt="">
            <img class="tm-logo-contrast uk-responsive-height" src="{{URL::to('assets/img/logo/1.jpg')}}" alt="">
        </a>

        <div class="uk-navbar-flip uk-visible-large">
            <ul class="uk-navbar-nav">
                <li class=" uk-active" >
                    <a href="">Home</a>
                </li>
                <li>
                    <a href="">About</a>
                </li>
                <li>
                    <a href="">Activities</a>
                </li>
                <li>
                    <a href="">Archieve</a>
                </li>
                <li>
                    <a href="">Event Calender</a>
                </li>
                <li>
                    <a href="">FAQ</a>
                </li>
                <li>
                    <a href="">Contact Us</a>
                </li>

            </ul>
        </div>

        <div class="uk-navbar-flip uk-hidden-large">
            <a href="#offcanvas" class="uk-navbar-toggle" data-uk-offcanvas></a>
        </div>

    </nav>

</div>