<!--                                 <div id="tm-bottom" class="tm-bottom uk-block uk-block-default" >

                    <section class="uk-grid uk-grid-match" data-uk-grid-margin>
                        <div class="uk-width-medium-1-1">

    <div class="uk-panel   ">


<div class="uk-grid uk-grid-width-medium-1-2 uk-margin-large" data-uk-grid-margin>
    <div class="uk-panel">
        <h3>Contact Us</h3>       
    </div>
    <div class="uk-panel">
      <ul class="uk-list">
          <li>2309 Street Name, City Postalcode</li>
          <li>Phone (12434) 567-89</li>
          <li>Fax (1234) 893-357</li>
      </ul>
     <a class="uk-button uk-button-link" href="#">Send us an Email</a>
    </div>
</div>
    </div>

</div>
                    </section>

                </div> -->
                
                <div id="tm-footer" class="tm-footer uk-block-secondary uk-contrast" style="background-color:#00abea">

                    <section class="uk-grid uk-grid-match" data-uk-grid-margin>
                        <div class="uk-width-medium-1-2">

                            <div class="uk-panel   ">


                            </div>

                        </div>
                        <div class="uk-width-medium-1-2" style="background-color:#00abea">

                            <div class="uk-panel   ">


                                <div class="uk-subnav uk-icon-medium uk-align-medium-right">
                                <a style="color:#fff" href="https://web.facebook.com/airlanggaMUNclub/" class="uk-icon-hover uk-icon-facebook"></a>
                                    <a style="color:#fff" href="https://twitter.com/airlanggamun" class="uk-icon-hover uk-icon-twitter"></a>
                                </div>
                            </div>

                        </div>
                    </section>

                </div>
                
            </div>
        </div>