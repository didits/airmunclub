                <div id="offcanvas" class="uk-offcanvas">
            <div class="uk-offcanvas-bar uk-offcanvas-bar-flip uk-text-center">

                                <div class="uk-panel uk-text-center">
                    <a href="/demo/theme-brick/">
                        <img src="{{URL::to('assets/img/logo/bw.png')}}" alt="">
                    </a>
                </div>
                
                                    <ul class="uk-nav uk-nav-offcanvas">

        <li class=" uk-active">
        <a href="/demo/theme-brick/">Home</a>

            </li>
        <li class="">
        <a href="/demo/theme-brick/about">About</a>

            </li>
        <li class="">
        <a href="/demo/theme-brick/team">Team</a>

            </li>
        <li class="">
        <a href="/demo/theme-brick/blog">Blog</a>

            </li>
        <li class="">
        <a href="/demo/theme-brick/positions">Positions</a>

            </li>
    
</ul>
                
                
            </div>
        </div>